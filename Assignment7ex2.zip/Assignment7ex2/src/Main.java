import java.util.HashMap;
import java.util.Map;

interface Document {
    void upload(String documentName);
    void download(String documentName);
    void edit(String documentName);
}

// RealSubject class
class DocumentStorage implements Document {
    private String document;

    @Override
    public void upload(String documentName) {
        System.out.println("Uploading document: " + documentName);
        document = documentName;
    }

    @Override
    public void download(String documentName) {
        System.out.println("Downloading document: " + documentName);
    }

    @Override
    public void edit(String documentName) {
        System.out.println("Editing document: " + documentName);
        document = documentName;
    }
}

// Proxy class
class DocumentProxy implements Document {
    private DocumentStorage documentStorage;
    private Map<String, Boolean> userPermissions;

    public DocumentProxy() {
        documentStorage = new DocumentStorage();
        userPermissions = new HashMap<>();
        userPermissions.put("user1", true);
        userPermissions.put("user2", false);
    }

    private boolean hasAccess(String user) {
        return userPermissions.containsKey(user) && userPermissions.get(user);
    }

    @Override
    public void upload(String documentName) {
        System.out.println("Proxy: Upload request received.");
        String user = getCurrentUser();
        if (hasAccess(user)) {
            documentStorage.upload(documentName);
        } else {
            System.out.println("Access denied. User does not have permission to upload.");
        }
    }

    @Override
    public void download(String documentName) {
        System.out.println("Proxy: Download request received.");
        String user = getCurrentUser();
        if (hasAccess(user)) {
            documentStorage.download(documentName);
        } else {
            System.out.println("Access denied. User does not have permission to download.");
        }
    }

    @Override
    public void edit(String documentName) {
        System.out.println("Proxy: Edit request received.");
        String user = getCurrentUser();
        if (hasAccess(user)) {
            documentStorage.edit(documentName);
        } else {
            System.out.println("Access denied. User does not have permission to edit.");
        }
    }

    private String getCurrentUser() {
        return "user1";
    }
}

// Client class
public class Main {
    public static void main(String[] args) {
        Document proxy = new DocumentProxy();
        proxy.upload("document1.txt");
        proxy.download("document1.txt");
        proxy.edit("document1.txt");
    }
}