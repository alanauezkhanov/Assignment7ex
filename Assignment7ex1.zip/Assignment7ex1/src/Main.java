class SupportRequest {
    private int id;
    private String description;
    private int priority;

    public SupportRequest(int id, String description, int priority) {
        this.id = id;
        this.description = description;
        this.priority = priority;
    }

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public int getPriority() {
        return priority;
    }
}

interface SupportHandler {
    void handleRequest(SupportRequest request);
}

class HardwareHandler implements SupportHandler {
    private SupportHandler nextHandler;

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public void handleRequest(SupportRequest request) {
        if (request.getPriority() <= 3) {
            System.out.println("HardwareHandler: Handling request with ID " + request.getId());
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }
}

class SoftwareHandler implements SupportHandler {
    private SupportHandler nextHandler;

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public void handleRequest(SupportRequest request) {
        if (request.getPriority() <= 2) {
            System.out.println("SoftwareHandler: Handling request with ID " + request.getId());
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }
}

class NetworkHandler implements SupportHandler {
    private SupportHandler nextHandler;

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public void handleRequest(SupportRequest request) {
        if (request.getPriority() <= 1) {
            System.out.println("NetworkHandler: Handling request with ID " + request.getId());
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }
}

class HelpDeskTicketingSystem {
    private SupportHandler handler;

    public void setHandler(SupportHandler handler) {
        this.handler = handler;
    }

    public void processRequest(SupportRequest request) {
        if (handler != null) {
            handler.handleRequest(request);
        } else {
            System.out.println("No handler available to process the request.");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        HardwareHandler hardwareHandler = new HardwareHandler();
        SoftwareHandler softwareHandler = new SoftwareHandler();
        NetworkHandler networkHandler = new NetworkHandler();

        hardwareHandler.setNextHandler(softwareHandler);
        softwareHandler.setNextHandler(networkHandler);

        HelpDeskTicketingSystem ticketingSystem = new HelpDeskTicketingSystem();
        ticketingSystem.setHandler(hardwareHandler);

        SupportRequest request1 = new SupportRequest(1, "Hardware issue", 3);
        SupportRequest request2 = new SupportRequest(2, "Software issue", 2);
        SupportRequest request3 = new SupportRequest(3, "Network issue", 1);
        SupportRequest request4 = new SupportRequest(4, "Miscellaneous issue", 4);

        ticketingSystem.processRequest(request1);
        ticketingSystem.processRequest(request2);
        ticketingSystem.processRequest(request3);
        ticketingSystem.processRequest(request4);
    }
}